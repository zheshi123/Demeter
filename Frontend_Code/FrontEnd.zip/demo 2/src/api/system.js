/**
* Created by zyt5668 on 2018/6/26.
*/
import axios from '../utils/axios'
import urls from '../config/system_url'
import { param } from 'jquery'
import {PROVIDER_ID} from "../config/target_url"

// 登录接口
export function login(params) {
  return axios({
    url: urls.URL_login,
    method: 'POST',
    data: params
  })
}
// 查询H5端观庙首页
export function queryLampTempleData(params) {
  return axios({
    url: urls.URL_queryLampTempleData,
    method: 'POST',
    data: params
  })
}
// 发送短信验证码
export function sendCode(params) {
  return axios({
    url: urls.URL_sent_code,
    method: 'POST',
    data: params
  })
}

export function getSysUrl(params) {
  return axios({
    url: urls.URL_sys_url,
    method: 'POST',
    data: params
  })
}
// 获取openID
export function getOpenID(params) {
  return axios({
    url: urls.URL_get_openID,
    method: 'POST',
    data: params
  })
}
// 微信预支付
export function wxPrePay(params) {
  return axios({
    url: urls.URL_wx_pre_pay,
    method: 'POST',
    data: params
  })
}
// 查询支付结果
export function queryPayResult(params) {
  return axios({
    url: urls.URL_query_pay_result,
    method: 'POST',
    data: params
  })
}

// 查询省市区
export function queryAreaList(params) {
  return axios({
    url: urls.query_area_list,
    method: 'GET',
    data: params
  })
}
// 查询法会列表
export function queryCommunionList(params) {
  params = Object.assign({providerId: PROVIDER_ID}, params)
  return axios({
    url: urls.query_communion_List,
    method: 'POST',
    data: params
  })
}
// 查询法会活动场次
export function queryCommunionDate(params) {
  params = Object.assign({providerId: PROVIDER_ID}, params)
  return axios({
    url: urls.query_communion_date,
    method: 'POST',
    data: params
  })
}

// 查询使用日期
export function queryDate(params) {
  return axios({
    url: urls.query_date,
    method: 'POST',
    data: params
  })
}

// 查询使用时间
export function queryInterval(params) {
  return axios({
    url: urls.query_interval,
    method: 'POST',
    data: params
  })
}

// 查询联系人
export function queryContact(params) {
  return axios({
    url: urls.query_contact,
    method: 'POST',
    data: params
  })
}

// 添加联系人
export function addContact(params) {
  return axios({
    url: urls.add_contact,
    method: 'POST',
    data: params
  })
}

// 更新联系人
export function updateContact(params) {
  return axios({
    url: urls.update_contact,
    method: 'POST',
    data: params
  })
}

// 删除联系人
export function deleteContact(params) {
  return axios({
    url: urls.delete_contact,
    method: 'POST',
    data: params
  })
}

// 批量更新/删除联系人
export function UpdateContactList(params) {
  return axios({
    url: urls.update_contact_list,
    method: 'POST',
    data: params
  })
}

// 订单提交
export function addOrder(params) {
  return axios({
    url: urls.add_order,
    method: 'POST',
    data: params
  })
}
// 法会法物订单提交

export function activityAddOrder(params) {
  params = Object.assign({providerId: PROVIDER_ID}, params)
  return axios({
    url: urls.activity_add_order,
    method: 'POST',
    data: params
  })
}
// 景区票型分组下票种详情查询
export function queryTicketGroupType(params) {
  return axios({
    url: urls.query_ticket_group_type,
    method: 'POST',
    data: params
  })
}

// 加签支付订单
export function spotsOrderPay(params) {
  return axios({
    url: urls.spots_order_pay,
    method: 'POST',
    data: params
  })
}

// 查询订单支付结果
export function queryOrderPayResult(params) {
  return axios({
    url: urls.query_order_pay_result,
    method: 'POST',
    data: params
  })
}

// 景点列表
export function querySpotsList(params) {
  return axios({
    url: urls.query_spots_list,
    method: 'POST',
    data: params
  })
}

// 景点详情
export function querySpotDetail(params) {
  return axios({
    url: urls.query_spot_detail,
    method: 'POST',
    data: params
  })
}

// 订单详情
export function queryOrderDetail(params) {
  return axios({
    url: urls.query_order_detail,
    method: 'POST',
    data: params
  })
}
// 法会订单预支付
export function activityPrePay(params) {
  return axios({
    url: urls.activity_pre_pay,
    method: 'POST',
    data: params
  })
}

// 法会订单查询支付结果
export function queryActivityPayResult(params) {
  return axios({
    url: urls.query_activity_pay_result,
    method: 'POST',
    data: params
  })
}

// 修改订单状态
export function changeOrderStatus(params) {
  return axios({
    url: urls.change_order_status,
    method: 'POST',
    data: params
  })
}

// 取消订单
export function cancelOrder(params) {
  return axios({
    url: urls.cancel_order,
    method: 'POST',
    data: params
  })
}

// 删除订单
export function deleteOrder(params) {
  return axios({
    url: urls.delete_order,
    method: 'POST',
    data: params
  })
}

// 查询退款详情
export function queryRefundOrderDetail(params) {
  return axios({
    url: urls.query_refund_orderDetail,
    method: 'POST',
    data: params
  })
}

// 法会订单详情
export function activityQueryOrderDetail(params) {
  return axios({
    url: urls.activity_query_order_detail,
    method: 'POST',
    data: params
  })
}


//查询订单列表
export function queryOrderList(params) {
  return axios({
    url: urls.query_order_list,
    method: 'POST',
    data: params
  })
}

// 法会取消订单
export function activityCancelOrder(params) {
  return axios({
    url: urls.activity_cancel_order,
    method: 'POST',
    data: params
  })
}

// 法会删除订单
export function activityHideOrder(params) {
  return axios({
    url: urls.activity_hide_order,
    method: 'POST',
    data: params
  })
}

// 法会退款详情
export function activityQueryRefundProcess(params) {
  return axios({
    url: urls.activity_query_refund_process,
    method: 'POST',
    data: params
  })
}

// 祈福灯背包详情
export function queryLampDetail(params) {
  params = Object.assign({providerId: PROVIDER_ID}, params)
  return axios({
    url: urls.query_lamp_detail,
    method: 'POST',
    data: params
  })
}

// 祈福灯殿堂信息
export function queryLampPalace(params) {
  params = Object.assign({providerId: PROVIDER_ID}, params)
  return axios({
    url: urls.query_lamp_palace,
    method: 'POST',
    data: params
  })
}
// 查询灯和区域
export function queryLampAreaInfo(params) {
  params = Object.assign({providerId: PROVIDER_ID}, params)
  return axios({
    url: urls.query_lamp_area_info,
    method: 'POST',
    data: params
  })
}

// 查询灯位置图数据
export function queryLampData(params) {
  return axios({
    url: urls.query_lamp_data,
    method: 'POST',
    data: params
  })
}
// 殿堂信息下拉框列表
export function queryPalaceDataList(params) {
  params = Object.assign({providerId: PROVIDER_ID}, params)
  return axios({
    url: urls.query_palace_data_list,
    method: 'POST',
    data: params
  })
}
// 祈福灯背包列表
export function queryLampList(params) {
  params = Object.assign({providerId: PROVIDER_ID}, params)
  return axios({
    url: urls.query_lamp_list,
    method: 'POST',
    data: params
  })
}

// 祈福灯详情
export function queryLampOrderDetail(params) {
  return axios({
    url: urls.query_lamp_order_detail,
    method: 'POST',
    data: params
  })
}

export function addLampOrder(params) {
  params = Object.assign({providerId: PROVIDER_ID}, params)
  return axios({
    url: urls.add_lamp_order,
    method: 'POST',
    data: params
  })
}

// 祈福灯信息登记页
export function queryLightRegDetail(params) {
  return axios({
    url: urls.query_light_reg_detail,
    method: 'POST',
    data: params
  })
}

// 祈福灯下单
export function lampAddOrder(params) {
  params = Object.assign({providerId: PROVIDER_ID}, params)
  return axios({
    url: urls.lamp_add_order,
    method: 'POST',
    data: params
  })
}

// 祈福灯预支付
export function lampPrePay(params) {
  return axios({
    url: urls.lamp_pre_pay,
    method: 'POST',
    data: params
  })
}

// 祈福灯查询支付结果
export function lampQueryPayResult(params) {
  return axios({
    url: urls.lamp_query_pay_result,
    method: 'POST',
    data: params
  })
}

// 祈福灯取消支付
export function lampUserStopPay(params) {
  return axios({
    url: urls.lamp_user_stop_pay,
    method: 'POST',
    data: params
  })
}

// 祈福灯待支付取消订单
export function lampCancelOrder(params) {
  return axios({
    url: urls.lamp_cancel_order,
    method: 'POST',
    data: params
  })
}

// 祈福灯删除订单
export function lampHideOrder(params) {
  return axios({
    url: urls.lamp_hide_order,
    method: 'POST',
    data: params
  })
}

// 内网模拟支付
export function monipay(params) {
  return axios({
    url: urls.lamp_moni_pay,
    method: 'POST',
    data: params,
    headers: {
      encryptType: '0'
    }
  })
}

//敬神功德信息登记
export function donationRegDetail(params) {
  return axios({
    url: urls.query_donation_reg_detail,
    method: 'POST',
    data: params,
  })
}

// 修改功德主信息
export function updateRegisterInfo(params) {
  params = Object.assign({providerId: PROVIDER_ID}, params)
  return axios({
    url: urls.update_register_info,
    method: 'POST',
    data: params
  })
}

// 查询敬神功德列表
export function queryDonationList(params) {
  params = Object.assign({providerId: PROVIDER_ID}, params)
  return axios({
    url: urls.query_donation_List,
    method: 'POST',
    data: params
  })
}

// 提交敬神功德订单
export function addDonationOrder(params) {
  params = Object.assign({providerId: PROVIDER_ID}, params)
  return axios({
    url: urls.add_donation_order,
    method: 'POST',
    data: params
  })
}

// 敬神功德订单详情
export function queryDonateOrderDetail(params) {
  return axios({
    url: urls.query_donate_order_detail,
    method: 'POST',
    data: params
  })
}

// 敬神功德 查询退款进度
export function queryDonateOrderRefundProcess(params) {
  return axios({
    url: urls.URL_queryDonateOrderRefundProcess,
    method: 'POST',
    data: params
  })
}
