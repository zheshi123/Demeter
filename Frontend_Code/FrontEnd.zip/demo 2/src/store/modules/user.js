import {getGlobalItem, setGlobalItem} from "../../utils";

const User = {
  state: {
    userID: '',
    userTel: '' || getGlobalItem('userTel'),
    openID: '' || getGlobalItem('openID'),
    action: '',
    autoLoginFlag: false
  },

  mutations: {
    setUserID: (state, userID) => {
      state.userID = userID
      // setGlobalItem('userID', userID)
    },

    setUserTel: (state, userTel) => {
      state.userTel = userTel
      setGlobalItem('userTel', userTel)
    },

    setOpenID: (state, openID) => {
      state.openID = openID
      setGlobalItem('openID', openID)
    },

    setAction: (state, action) => {
      state.action = action
    },

    setAutoLoginFlag: (state, flag) => {
      state.autoLoginFlag = flag
    },

    logout: (state) => {
      state.userID = ''
      // setGlobalItem('userID', '')
      // state.userTel = ''
      // setGlobalItem('userTel', '')
      state.action = ''
    },
  },

  getters: {
    userID: state => state.userID,
    openID: state => state.openID,
    action: state => state.action,
    userTel: state => state.userTel,
    userTelEscape: state => {
      return state.userTel.substring(0, 3) + "****" + state.userTel.substring(7)
    },
    autoLoginFlag: state => state.autoLoginFlag
  }
}

export default User

