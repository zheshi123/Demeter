// 订单信息
const orderInfo = {
  state: {
    reservationInfo: {},
    contactInfo: {},
    orderNo: "",
    pageInfo: {},
    ticketTypes:{},//票的信息
    needElement:{},//必输项
  },

  mutations: {
    SET_RESERVATION_INFO: (state, reservationInfo) => {
      state.reservationInfo = reservationInfo
    },

    SET_CONTACT_INFO: (state, contactInfo) => {
      state.contactInfo = contactInfo
    },

    SET_ORDER_NO: (state, orderNo) => {
      state.orderNo = orderNo
    },

    SET_PAGE_INFO: (state, pageInfo) => {
      state.pageInfo = pageInfo
    },
  
    SET_TICKET_TYPES: (state, ticketTypes) => {
      state.ticketTypes = ticketTypes
    },
  
    SET_NEED_ELEMENT: (state, needElement) => {
      state.needElement = needElement
    },
  },

  actions: {
    // 保存登记信息
    saveReservationInfo({commit}, response) {
      return new Promise((resolve, reject) => {
        commit('SET_RESERVATION_INFO', response)
        resolve()
      })
    },

    // 保存联系人信息
    saveContactInfo({commit}, response) {
      return new Promise((resolve, reject) => {
        commit('SET_CONTACT_INFO', response)
        resolve()
      })
    },

    // 保存订单号
    saveOrderNo({commit}, response) {
      return new Promise((resolve, reject) => {
        commit('SET_ORDER_NO', response)
        resolve()
      })
    },

    // 保存页面传递的数据
    savePageInfo({commit}, response) {
      return new Promise((resolve, reject) => {
        commit('SET_PAGE_INFO', response)
        resolve()
      })
    },
  
    // 下单页保存ticketType
    saveTicketTypes({commit}, response) {
      return new Promise((resolve, reject) => {
        commit('SET_TICKET_TYPES', response)
        resolve()
      })
    },
  
    // 保存必输选输
    saveNeedElement({commit}, response) {
      return new Promise((resolve, reject) => {
        commit('SET_NEED_ELEMENT', response)
        resolve()
      })
    },
  },

  getters: {
    getReservationInfo: state => state.reservationInfo,
    getContactInfo: state => state.contactInfo,
    getOrderNo: state => state.orderNo,
    getPageInfo: state => state.pageInfo,
    getTicketTypes: state => state.ticketTypes,
    getNeedElement: state => state.needElement,
  }
}

export default orderInfo

