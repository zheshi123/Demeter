export const SYSTEM_URL = '/ctsp-ali'
export const PAY_URL = '/v3'
// export const SYSTEM_URL = '/ctsp-gateway'

export const ENCRYPT_KEY = 'TR75O2E740UE58F9'
export const CLIENT_ID = '141'
export const PROVIDER_ID = '234'

global.appId = 'wxfdb74947029fb4c9' // 开发环境
global.h5url = 'https://ctour.fintechboc.com/temple/'
global.oauthUrl = `https://open.weixin.qq.com`
