/**
 * Created by zyt5668 on 2018/6/26.
 */
/**
 * URL地址全局参数
 * TODO 投产打包检查点
 */

import {SYSTEM_URL} from './target_url'
import {PAY_URL} from './target_url'

/**
 * 接口URL地址
 */
export default {
  // 登录接口
  URL_login: SYSTEM_URL + '/user/unlogin/signIn',
  // 短信验证码
  URL_sent_code: SYSTEM_URL + '/unlogin/sentMessage',
  // 查询H5端观庙首页
  URL_queryLampTempleData: SYSTEM_URL + '/ctc/unlogin/queryLampTempleData',
  // 图形验证码
  URL_image_code: SYSTEM_URL + '/unlogin/sysfile/getImageValiteCode',
  URL_sys_url: SYSTEM_URL + '/unlogin/getSysUrl',
  // openID
  URL_get_openID: SYSTEM_URL + '/unlogin/getopenid',
  // 预支付
  URL_wx_pre_pay: '/ctsppay/common/prePay',
  // 支付结果查询
  URL_query_pay_result: '/ctsppay/common/queryPayResult',
  // 省市区查询
  query_area_list: SYSTEM_URL + '/unlogin/contact/querydistrict',
  // 查询法会活动场次
  query_communion_List: SYSTEM_URL + '/ctc/unlogin/active/queryActiveList',
  // 查询法会活动场次
  query_communion_date: SYSTEM_URL + '/ctc/unlogin/active/queryActiveDetail',
  // 使用日期查询
  query_date: SYSTEM_URL + '/unlogin/scenic/date/query',
  // 使用时间查询
  query_interval: SYSTEM_URL + '/unlogin/scenic/querySpotsIntervalLeftTicket',
  // 联系人查询
  query_contact: SYSTEM_URL + '/user/userContant/newQueryPeople',
  // 新增联系人
  add_contact: SYSTEM_URL + '/user/userContant/save',
  // 更新联系人
  update_contact: SYSTEM_URL + '/user/userContant/newUpdate',
  // 删除联系人
  delete_contact: SYSTEM_URL + '/user/userContant/delete',
  // 联系人批量新增/编辑
  update_contact_list: SYSTEM_URL + '/user/userContant/updateUserList',
  // 订单提交
  add_order: SYSTEM_URL + '/order/addOrder',
  // 景区票型分组下票种详情查询
  query_ticket_group_type: SYSTEM_URL + '/scenic/ticketGroupType/query',
  // 加签支付订单
  spots_order_pay: SYSTEM_URL + '/pay/spotsOrderPay',
  // 查询订单支付结果
  query_order_pay_result: SYSTEM_URL + '/pay/queryOrderPayResult',
  // 景点列表
  query_spots_list: SYSTEM_URL + '/unlogin/scenic/querySpotsList',
  // 景点详情
  query_spot_detail: SYSTEM_URL + '/unlogin/scenic/querySpotDetail',
  // 订单详情
  query_order_detail: SYSTEM_URL + '/order/queryOrderDetail',
  // 法会法物订单提交
  activity_add_order: SYSTEM_URL + '/ctc/addOrder',
  // 法会订单预支付
  activity_pre_pay: SYSTEM_URL + '/ctc/prePay',
  // 法会订单查询支付结果
  query_activity_pay_result: SYSTEM_URL + '/ctc/queryPayResult',
  // 修改订单状态
  change_order_status: SYSTEM_URL + '/order/changeOrderStatus',
  // 取消订单
  cancel_order: SYSTEM_URL + '/order/cancelOrder',
  // 删除订单
  delete_order: SYSTEM_URL + '/order/removeOrder',
  // 查询退款详情
  query_refund_orderDetail: SYSTEM_URL + '/order/queryRefundOrderDetail',
  // 法会订单详情
  activity_query_order_detail: SYSTEM_URL + '/ctc/order/queryOrderDetail',
  // 查询订单列表
  query_order_list: SYSTEM_URL + '/cdq/queryOrderList',
  // 法会取消订单
  activity_cancel_order: SYSTEM_URL + '/ctc/order/cancelOrder',
  // 法会删除订单
  activity_hide_order: SYSTEM_URL + '/ctc/order/hideOrder',
  // 法会退款详情
  activity_query_refund_process: SYSTEM_URL + '/ctc/order/queryRefundProcess',
  // 祈福灯背包详情
  query_lamp_detail: SYSTEM_URL + '/ctc/mineLamp/queryLampDetail',
  // 祈福灯殿堂信息
  query_lamp_palace: SYSTEM_URL + '/ctc/unlogin/queryPalaceInfo',
  // 查询灯和区域
  query_lamp_area_info: SYSTEM_URL + '/ctc/lamp/queryBasicRegisterInfo',
  // 查询灯位置图
  query_lamp_data: SYSTEM_URL + '/ctc/unlogin/lampChoiceData',
  // 殿堂信息下拉框列表
  query_palace_data_list: SYSTEM_URL + '/ctc/lamp/queryPalaceDataList',
  // 祈福灯背包列表
  query_lamp_list: SYSTEM_URL + '/ctc/mineLamp/queryLampList',
  // 祈福灯详情
  query_lamp_order_detail: SYSTEM_URL + '/ctc/unlogin/queryLampOrderDetail',
  // 提交祈福灯订单
  add_lamp_order: SYSTEM_URL + '/ctc/lamp/addOrder',
  // 祈福灯信息登记页
  query_light_reg_detail: SYSTEM_URL + '/ctc/lamp/queryNeedInfo',
  // 祈福灯下单
  lamp_add_order: SYSTEM_URL + '/ctc/lamp/addOrder',
  // 祈福灯预支付
  lamp_pre_pay: SYSTEM_URL + '/ctc/lamp/prePay',
  // 祈福灯查询支付结果
  lamp_query_pay_result: SYSTEM_URL + '/ctc/lamp/queryPayResult',
  // 祈福灯取消支付
  lamp_user_stop_pay: SYSTEM_URL + '/ctc/lamp/userStopPay',
  // 祈福灯待支付取消订单
  lamp_cancel_order: SYSTEM_URL + '/ctc/lamp/cancelOrder',
  // 祈福灯删除订单
  lamp_hide_order: SYSTEM_URL + '/ctc/lamp/hideOrder',
  // 模拟支付
  lamp_moni_pay: PAY_URL + '/pay/transactions/jsapi/payed',
  // 敬神功德信息登记页
  query_donation_reg_detail: SYSTEM_URL + '/ctc/donate/queryNeedInfo',
  // 修改功德主信息
  update_register_info: SYSTEM_URL + '/ctc/lamp/updateRegisterInfo',
  // 查询敬神功德列表
  query_donation_List: SYSTEM_URL + '/ctc/unlogin/donate/queryDonateInfo',
  // 提交敬神功德订单
  add_donation_order: SYSTEM_URL + '/ctc/donate/addOrder',
  // 敬神功德订单详情
  query_donate_order_detail: SYSTEM_URL + '/ctc/donate/queryDonateOrderDetail',
  // 敬神功德 查询退款进度
  URL_queryDonateOrderRefundProcess: SYSTEM_URL + '/ctc/donate/queryDonateOrderRefundProcess',
}
