<template>
  <div class="consulting">
    <div class="title">Intelligent Plants</div>
    <img src="../../assets/images/corn.svg" style="width:100%; margin-top: 50px; margin-left: 10px">
    <div style="margin-left:30px; margin-top: 20px; text-align: center; font-size: 20px; font-weight: bold; ">Your Corn is SUFFERING!!!!</div>
    <div style="margin-top: 30px; margin-left: 30px; width: 40%; float: left;">
      <img src="../../assets/images/humidity.svg" style="width: 45px; float: left">
      <div style="float: right">
        <div style="font-size: 18px; margin-bottom: 5px;">Humidity</div>
        <div style="font-size: 18px; font-weight: bold; color: red">50%</div>
      </div>
    </div>
    <div style="margin-top: 30px; margin-right: 20px; width: 30%; float: right;">
      <img src="../../assets/images/temperature.svg" style="width: 45px; float: left">
      <div style="float: right">
        <div style="font-size: 18px; margin-bottom: 5px;">Temp</div>
        <div style="font-size: 18px; font-weight: bold; color: red">28°C</div>
      </div>
    </div>
    <div style="margin-top: 30px; margin-left: 70px; width: 55%; float: left;">
      <img src="../../assets/images/cornstage.svg" style="width: 45px; float: left">
      <div style="float: right">
        <div style="font-size: 18px; margin-bottom: 5px;">Growth Stage</div>
        <div style="font-size: 18px; font-weight: bold;">V6(6th leaf)</div>
      </div>
    </div>
    <div style="margin-left: 25px;padding-top: 20px; clear: both; width: 75%; height: 45px">
      <img src="../../assets/images/notice.svg" style="width: 45px; float: left;">
      <div style="float: right; font-size: 20px; margin-left: 10px; line-height: 45px; font-weight: bolder">What should I do?</div>
    </div>
    <div style="margin-left: 30px; margin-top: 20px;">
      <p>1. Watering your plants!!!!! Right now!!</p>
      <p>2. Lower the temprature to 20°C-</p>
      <p style="margin-left: 15px;">23°C during the V6 stage</p>
      <p>3. Burpee Organic Fertilizer is</p>
      <p style="margin-left: 15px;">ON SALE! Time to buy!</p>
      <p style="margin-left: 40px;">-23°C during the V6 stage</p>
      <p style="margin-left: 40px;">-23°C during the V6 stage</p>
    </div>
  </div>
</template>

<script>
  export default {
    name: 'ClaimNotice',
    data() {
      return {

      }
    },
    methods: {
      goLaunch() {
        this.$router.push('ClaimLaunch')
      }
    },
  }
</script>

<style scoped>
  .consulting {
    width: 90%;
    height: 100vh;
    padding: 16px;
    box-sizing: border-box;
    position: relative;
  }

  .title {
    margin-left: 30%;
    margin-top: 20px;
    color: rgb(4 163 155);
    font-size: 22px;
    font-weight: bold;
    margin-bottom: 10px;
  }

  .subtitle {
    margin: 20px 20px;
    font-size: 18px;
    font-weight: bold;
    display:flex;
    justify-content:flex-start;
  }
</style>