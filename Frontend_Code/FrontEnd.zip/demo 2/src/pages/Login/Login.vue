<template>
  <div class="container">
    <div>
      <div class="text-login">{{loginStatus === 2 ? '请绑定手机号' : '登录'}}</div>
      <div class="text-welcome">欢迎来到农业银保通</div>
      <div class="mobile-container">
        <img class="icon-user" src="../../assets/icon_user_login.png">
        <input type="number" placeholder="请输入手机号码" oninput="if(value.length>11) value=value.slice(0,11)" @focus="inputClear1 = true" @blur="inputClear1 = false" v-model="mobile">
        <img v-if="inputClear1" class="icon-clear" src="../../assets/icon_clear_login.png" @mousedown="clear(1)">
      </div>
      <div class="mobile-container">
        <img class="icon-user" src="../../assets/icon_safe_login.png">
        <input type="number" placeholder="请输入图形验证码" oninput="if(value.length>4) value=value.slice(0,4)" @focus="inputClear2 = true" @blur="inputClear2 = false" v-model="captcha">
        <img v-if="inputClear2" class="icon-clear" src="../../assets/icon_clear_login.png" @mousedown="clear(2)">
        <img class="img-captcha" :src="captchaUrl" @click="beforeGetCaptcha"/>
      </div>
      <div class="mobile-container">
        <img class="icon-user" src="../../assets/icon_password_login.png">
        <input type="number" placeholder="请输入验证码" oninput="if(value.length>6) value=value.slice(0,6)" @focus="inputClear3 = true" @blur="inputClear3 = false" v-model="verificationCode">
        <img v-if="inputClear3" class="icon-clear" src="../../assets/icon_clear_login.png" @mousedown="clear(3)">
        <div class="btn-verification" :class="{'btn-verification-invaild' : !verificationClickable }" @click="getVerificationCode">{{verificationText}}</div>
      </div>
      <div class="btn-login" :class="{'btn-login-clickable' : loginClickable }" @click="loginByTel">{{loginStatus === 2 ? '绑定' : '登录/注册'}}</div>
      <div v-if="loginStatus !== 2" class="text-login-tip">未注册的手机号码验证后自动注册</div>
    </div>

    <div v-if="loginStatus !== 2">
      <div class="other-way-line">
        <div class="line"></div>
        <div class="text-other-way">其他登录方式</div>
        <div class="line"></div>
      </div>
      <div class="wx-login-container">
        <img class="icon-wx-login" src="../../assets/icon_wx_login.png" @click="beforeLoginByWx">
      </div>
      <div class="text-login-tip margin-bottom-32">登录注册即代表同意<span class="text-privacy-tip">《隐私政策》</span></div>
    </div>
  </div>
</template>

<script>
import {getSysUrl, sendCode, login, getOpenID} from "../../api/system"
import {getRandomUuid, isWeixin} from "../../utils";
import {check4Number, checkPhone, checkSixNumber} from "../../utils/validate";
import {CLIENT_ID} from "../../config/target_url";
import {mapGetters, mapMutations, mapState} from "vuex";
import { Indicator } from 'mint-ui';

export default {
  name: "Login",
  data () {
    return {
      mobile: '',
      captcha: '',
      verificationCode: '',
      inputClear1: false,
      inputClear2: false,
      inputClear3: false,
      loginClickable: false,
      captchaUrl: '',
      verificationText: '发送验证码',
      verificationClickable: true,
      time: 4,
      url: '',
      nextPage: 'Home',
      loginStatus: 0, // 0未登录，1手机号登陆，2微信登录
      code: '', // 微信用户授权获取code
    }
  },
  // 获取code逻辑在main.js中实现
  // beforeRouteEnter (to, from, next) {
  //   if (isWeixin && process.env.NODE_ENV === 'production') {
  //     if(location.href.indexOf('code') !== -1) {
  //       if (to.query.code) {
  //         next()
  //       } else {
  //         let codeReg = new RegExp('(^|&?)' + 'code' + '=([^&]*)(&|#|$)', 'i')
  //         let code = location.href.match(codeReg)
  //         if (code && code[2]) {
  //           let redirectUri = global.h5url + '#' + to.path + '?code=' + unescape(code[2]) + '&nextPage=' + to.query.nextPage
  //           window.location.href = redirectUri
  //         }
  //         /*if (code && code[2]) {
  //           next(vm => {
  //             vm.code = unescape(code[2])
  //           })
  //         }
  //         next()*/
  //       }
  //     } else {
  //       let redirectUri = global.h5url + '#' + to.fullPath
  //       window.location.href = `${global.oauthUrl}/connect/oauth2/authorize?appid=${global.appId}&redirect_uri=${encodeURIComponent(redirectUri)}&response_type=code&scope=snsapi_base#wechat_redirect`
  //     }
  //   } else {
  //     next()
  //   }
  // },
  created() {
    // this.code = this.$route.query.code
    this.nextPage = this.$route.query.nextPage
    // if (this.code) {
    //   this.getOpenID()
    // }
    this.querySysUrl()
  },
  mounted() {
  },
  watch: {
    mobile: {
      handler(newMobile, oldMobile) {
        if(checkPhone(newMobile)) {
          this.beforeGetCaptcha()
        }
        if(checkPhone(newMobile) && checkSixNumber(this.verificationCode)) {
          this.loginClickable = true
        } else {
          this.loginClickable = false
        }
      }
    },
    verificationCode: {
      handler(newCode, oldCode) {
        if(checkSixNumber(newCode) && checkPhone(this.mobile)) {
          this.loginClickable = true
        } else {
          this.loginClickable = false
        }
      }
    }
  },
  computed: {
    ...mapGetters([
      'userID',
      'openID',
      'userTel'
    ])
  },
  methods: {
    ...mapMutations([
      'setUserID',
      'setUserTel',
      'setOpenID',
      'setAction'
    ]),
    querySysUrl() {
      getSysUrl().then(res => {
        if(res.errcode == '00') {
          this.url = res.data
          this.getCaptcha()
        } else {
          this.url = ''
        }
      }).catch(err => {
        this.url = ''
      })
    },
    beforeGetCaptcha() {
      if (!checkPhone(this.mobile)) {
        this.$toast({
          message: '手机号无效',
          duration: 2000
        })
        return
      }
      if(this.url) {
        this.getCaptcha()
      } else {
        this.querySysUrl()
      }
    },
    getCaptcha() {
      const uuid = getRandomUuid()
      console.log(this.time)
      if (this.time === 4) {
        this.time--
        const interval = setInterval(() => {
          this.time--
          if (this.time === 0) {
            clearInterval(interval)
            this.time = 4
          }
        }, 1000)
        this.captchaUrl = this.url + '/unlogin/sysfile/getImageValiteCode?clientId=' + CLIENT_ID + '&peopleTel=' + this.mobile + '&imageUuid=' + uuid
      }
    },
    // 获取短信验证码
    getVerificationCode() {
      if(!this.verificationClickable) {
        return
      }
      if (!checkPhone(this.mobile)) {
        this.$toast({
          message: '手机号无效',
          duration: 2000
        })
        return
      } else if(!check4Number(this.captcha)) {
        this.$toast({
          message: '图形验证码无效',
          duration: 2000
        })
      } else {
        const options = {
          peopleTel: this.mobile,
          bussType: '01',
          captcha: this.captcha
        }
        sendCode(options).then(response => {
          if (response.errcode === '00') {
            this.$toast({
              message: '验证码已发送',
              duration: 2000
            })
            this.verificationClickable = false
            let time = 60
            this.verificationText = '重新发送(' + time + ')'
            const interval = setInterval(() => {
              time--
              this.verificationText = '重新发送(' + time + ')'
              if (time === 0) {
                clearInterval(interval)
                this.verificationClickable = true
                this.verificationText = '发送验证码'
              }
            }, 1000)
          } else {
            // this.$toast({
            //   message: '验证码发送失败，请稍后重试',
            //   duration: 2000
            // })
          }
        }).catch(e => {
          if (e.errcode === '120057' || e.errcode === '120058') {
            this.beforeGetCaptcha()
          }
          // this.$toast({
          //   message: '验证码发送失败，请稍后重试',
          //   duration: 2000
          // })
        })
      }
    },
    /**
     * 登录
     */
    loginByTel() {
      if (!this.loginClickable) {
        return
      }
      if (!checkPhone(this.mobile)) {
        this.$toast({
          message: '手机号无效',
          duration: 2000
        })
        return
      } else if(!checkSixNumber(this.verificationCode)) {
        this.$toast({
          message: '图形验证码无效',
          duration: 2000
        })
      }
      // 短信验证码登录
      const params = {
        loginType: 4,
        phoneNum: this.mobile,
        msgCode: this.verificationCode,
        openId: this.openID
      }
      this.login(params)
    },
    login(params) {
      Indicator.open()
      // 登录
      login(params).then(res => {
        if (res.errcode === '00') {
          this.setUserID(res.peopleEntity.userId)
          this.setUserTel(res.peopleEntity.peopleTel)
          this.setAction(res.acton)
          this.$toast({
            message: '登录成功',
            duration: 2000
          })
          if (this.nextPage) {
            this.$router.replace(this.nextPage)
          } else {
            this.$router.replace('Home')
          }
        } else {
          // this.$toast({
          //   message: '登录失败',
          //   duration: 2000
          // })
        }
      }).catch(e => {
        // this.$toast({
        //   message: '登录失败',
        //   duration: 2000
        // })
      }).finally(() => {
        Indicator.close()
      })
    },
    clear(item) {
      switch (item) {
        case 1:
          this.mobile = ''
          break
        case 2:
          this.captcha = ''
          break
        case 3:
          this.verificationCode = ''
          break
      }
    },
    getOpenID() {
      // 获取openID并判断是否有手机号
      const params = {
        appId: global.appId,
        code: this.code,
        granType: 'authorization_code',
      }
      getOpenID(params).then(res => {
        if (res.errcode === '00' && res.openid) {
          this.setOpenID(res.openid.openid)
          if (res.phoneNum) {
            this.setUserTel(res.phoneNum)
          }
        }
      }).catch(e => {
      })
    },
    beforeLoginByWx() {
      if (this.openID && this.userTel) {
        this.loginByWx()
      } else {
        this.loginStatus = 2
      }
    },
    loginByWx() {
      // 微信openID与手机号登录
      const params = {
        loginType: 4,
        msgCode: '',
        phoneNum: this.userTel,
        openId: this.openID
      }
      this.login(params)
    }
  }
}

</script>

<style scoped>
input {
  font-family: PingFangSC-Regular;
  font-weight: 400;
  font-size: 14px;
  /*color: rgba(0,0,0,0.20);*/
  color: #000000;
  letter-spacing: 0;
  padding: 0 8px;
  flex-grow: 1;
  width: 100px;
}

.container {
  width: 74.7%;
  margin: 0 auto;
  overflow: hidden;
  min-height: 100vh;
  display: flex;
  flex-direction: column;
  justify-content: space-between;
}

.text-login {
  font-family: PingFangSC-Semibold;
  font-weight: 600;
  font-size: 28px;
  color: #000000;
  letter-spacing: 0;
  line-height: 40px;
  margin-top: 88px;
}

.text-welcome {
  font-family: PingFangSC-Regular;
  font-weight: 400;
  font-size: 16px;
  color: rgba(0,0,0,0.80);
  letter-spacing: 0;
  margin: 8px 0 14px;
}

.mobile-container {
  width: 100%;
  height: 48px;
  display: flex;
  align-items: center;
  border-bottom: 1px solid rgba(0,0,0,0.10);
}

.icon-user {
  width: 20px;
  height: 20px;
  flex-shrink: 0;
}

.icon-clear {
  width: 13.5px;
  height: 13.5px;
  flex-shrink: 0;
}

.img-captcha {
  width: 80px;
  height: 28px;
  margin-left: 16px;
  flex-shrink: 0;
}

.btn-verification {
  width: 80px;
  height: 28px;
  line-height: 28px;
  background: rgba(0,0,0,0.05);
  border-radius: 16px;
  font-family: PingFangSC-Regular;
  font-weight: 400;
  font-size: 12px;
  color: #000000;
  letter-spacing: 0;
  text-align: center;
  margin-left: 16px;
  flex-shrink: 0;
}

.btn-verification-invaild {
  color: rgba(0,0,0,0.40);
}

.btn-login {
  width: 100%;
  height: 40px;
  margin-top: 40px;
  background: #74A3B5;
  border-radius: 20px;
  font-family: PingFangSC-Regular;
  font-weight: 400;
  font-size: 16px;
  color: #FFFFFF;
  letter-spacing: 0;
  text-align: center;
  line-height: 40px;
  box-shadow: 0px 0px 8px 0px rgba(0, 122, 170, 0.2);
}

.btn-login-clickable {
  background: linear-gradient(133deg, #007AAA 0%, #004E93 100%);
}

.text-login-tip {
  width: 100%;
  margin-top: 16px;
  font-family: PingFangSC-Regular;
  font-weight: 400;
  font-size: 12px;
  color: rgba(0,0,0,0.60);
  letter-spacing: 0;
  text-align: center;
}

.other-way-line {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 40px;
  /*margin-top: 138px;*/
}

.line {
  height: 1px;
  background: rgba(0,0,0,0.10);
  flex-grow: 1;
}

.text-other-way {
  margin: 0 12px;
  font-family: PingFangSC-Regular;
  font-weight: 400;
  font-size: 12px;
  color: rgba(0,0,0,0.40);
  letter-spacing: 0;
}

.wx-login-container {
  display: flex;
  justify-content: center;
  margin: 16px 0 32px;
}

.icon-wx-login {
  width: 39.6px;
  height: 39.6px;
}

.text-privacy-tip {
  color:#007AAA;
}

.margin-bottom-32 {
  margin-bottom: 32px;
}
</style>
