<template>
  <div class="outer-container">
    <!-- 新增按钮 -->
    <div class="add-container">
      <div class="increase" @click="editContact(-1)">
        <img src="../../assets/images/circle_add_blue.png" alt="add">  新增
      </div>
    </div>
    <div class="contact-list-wrapper">
      <div class="contact-item" v-for="(item,index) in contactList" :key="index">
        <div class="perItem" @click="editContact(index)">
          <div class="left">
            <div class="title">{{ item.contantName }}</div>
            <div class="cell" v-if="item.contantTel && item.contantTel.trim().length !== 0">
              <span class="info-title">手机号码 </span>
              <span class="info-content">{{ item.contantTel | formatByStar(3,4)}}</span>
            </div>
            <div class="cell" v-if="item.contantIdno && item.contantIdno.trim().length !== 0">
              <span class="info-title">身份证号 </span>
              <span class="info-content">{{ item.contantIdno | formatByStar(6)}}</span>
            </div>
          </div>
          <div class="right">
            <img src="../../assets/rightArrow.png" alt="edit">
          </div>
      </div>
      </div>
    </div>
  </div>
</template>

<script>
  import {queryContact} from "../../api/system";
  import {formatByStar} from "../../utils/filter"
  export default {
    name: "ContactList",
    data: function () {
      return {
        contactList:[],
      }
  },

  computed: {
  },

  created: function () {
    this.getNeedElement()
    this.queryContactData()
  },

  methods: {
    editContact: function (index) {
      let contactInfo = {}
      if (index === -1) {
        contactInfo.editType = 1 // 新增
      } else {
        contactInfo = this.contactList[index]
        contactInfo.editType = 2 // 编辑
      }
      this.$store.dispatch('saveContactInfo', contactInfo).then(() => {
        this.$router.push('/EditContact')
      })
    },

    // 查询联系人
    queryContactData() {
      const params = {
        userId: this.$store.getters.userID
      }
      queryContact(params).then(res => {
        if (res.errcode === '00') {
          console.log('res',res)
          this.contactList = res.list[0].contactList
        }
      })
    },
    
    getNeedElement:function () {
      let prayerNeedElement = {// 必输项 用于传值
        from:'contactList',//从我的页面进入
        needPrayerName:1,
        needPrayernickName:0,//称谓 非必输
        needPrayerPhone:1,
        needPrayerID:1,
        needPrayerlunarBirthday:1,
        needPrayerlunarHour:1,
        needPrayergender:1,
        needPrayerAddress:1,
      }
      this.$store.dispatch('saveNeedElement', prayerNeedElement)//保存必输项
    }
  }
}
</script>

<style scoped>
.add-container{
  display: flex;
  width: 100%;
  height: 80px;
  background: #F3F4F5;
}
.increase {
  width: 100%;
  height: 48px;
  background: #FFFFFF;
  border-radius: 8px;
  font-size: 14px;
  font-family: PingFangSC-Regular, PingFang SC;
  font-weight: 400;
  color: #007AAA;
  margin: 16px;
  display: flex;
  align-items: center;
  justify-content: center;
}
.increase > img {
  width: 15px;
  height: 15px;
  margin-right: 9px;
}
.perItem{
  margin: 16px;
  display: flex;
  justify-content: space-between;
  padding-bottom: 12px;
  border-bottom: 1px solid rgba(0,0,0,0.10);
}
.title{
  font-family: PingFangSC-Regular;
  font-size: 14px;
  color: #000000;
  font-weight: 400;
}
.info-title{
  font-size: 12px;
  color: rgba(0,0,0,0.40);
  font-weight: 400;
  margin-right: 8px;
}
.info-content{
  font-size: 12px;
  color: rgba(0,0,0,0.80);
  font-weight: 400;
}
.cell{
  font-family: PingFangSC-Regular;
  display: flex;
  flex-direction: row;
  margin: 4px 0;
}
.right{
  display: flex;
  align-items: center;
  justify-content: center;
}

.perItem .right img {
  width: 7px;
  height: 11px;
  margin-left: 5px;
}

</style>
