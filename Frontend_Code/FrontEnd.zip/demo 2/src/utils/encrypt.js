/**
 * Created by zcq5592 on 2017/11/21.
 */
import CryptoJS from 'crypto-js'
import smCrypto from 'sm-crypto'
import {CLIENT_ID, ENCRYPT_KEY} from "../config/target_url";
// import { SM2 } from 'gm-crypto'

export function getSecretKey(uuid) {
  const secretKey = CLIENT_ID + uuid.substr(5, 13)
  const md5SecretKey = CryptoJS.SHA256(secretKey).toString()
  const iv = (md5SecretKey.substr(0, 16)).toUpperCase()
  return iv
  // localStorage.setItem('sys.iv', iv)
}

export function getRandomUuid() { // 生成32位随机uuid
  const chars = ['0', '1', '2', '3', '4', '5', '6', '7', '8', 'a', 'b', 'c', 'd', 'e', 'f', 'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 'w', 'x', 'y', 'z']
  let res = ''
  for (let i = 0; i < 32; i++) {
    const id = Math.ceil(Math.random() * 32)
    res += chars[id]
  }
  return res
}

// 加密
export function encrypt(data, uuid) {
  // const uuid = getRandomUuid()
  // localStorage.setItem('sys.uuid', uuid)
  var key = CryptoJS.enc.Utf8.parse(ENCRYPT_KEY)
  var iv = CryptoJS.enc.Utf8.parse(getSecretKey(uuid))
  var srcs = CryptoJS.enc.Utf8.parse(data)
  var encrypted = CryptoJS.AES.encrypt(srcs, key, { iv: iv, mode: CryptoJS.mode.CBC })
  return encrypted.toString()
}

// 解密
export function decrypt(data, uuid) {
  var key = CryptoJS.enc.Utf8.parse(ENCRYPT_KEY)
  var iv = CryptoJS.enc.Utf8.parse(getSecretKey(uuid))
  var decrypt = CryptoJS.AES.decrypt(data, key, { iv: iv, mode: CryptoJS.mode.CBC })
  return CryptoJS.enc.Utf8.stringify(decrypt).toString()
}

// 文件加密
export function encryptFile(data) {
  const uuid = getRandomUuid()
  // const uuid = 'damnfts238kclcbbeg3joj3undefineddzgrntc3'
  localStorage.setItem('sys.uuid', uuid)
  getSecretKey(uuid)
  var key = CryptoJS.enc.Utf8.parse('TR75O2E740UE58F9')
  var iv = '1234567898765432'
  var srcs = CryptoJS.enc.Utf8.parse(data)
  var encrypted = CryptoJS.AES.encrypt(srcs, key, { iv: iv, mode: CryptoJS.mode.CBC })
  return encrypted.toString()
}

// 文件解密
export function decryptFile(word) {
  var key = CryptoJS.enc.Utf8.parse('TR75O2E740UE58F9')
  var iv = '1234567898765432'
  var decrypt = CryptoJS.AES.decrypt(word, key, { iv: iv, mode: CryptoJS.mode.CBC })
  return CryptoJS.enc.Utf8.stringify(decrypt).toString()
}

const sm2 = smCrypto.sm2
const publicKey = '0449DF480799C4B2BE52FD914D50F761CB26F3474502D4D272E46A6B1A6A573C4CD9E4C87691200661DC174DB68973AA97DA93CA52BB7F49EDC17B0ABC3BD84BEB'
const privateKey = '5DE2593ACF4E7D51AEC81A92F1D7651B7D890C774853D365B11500B6B354E533'
const cipherMode = 1 // 1 - C1C3C2，0 - C1C2C3，默认为1

// 加密
export function sm2Encrypt(data) {
  // const { publicKey, privateKey } = SM2.generateKeyPair()
  const encryptData = '04' + sm2.doEncrypt(data, publicKey, cipherMode)
  // const encryptData = SM2.encrypt(msg, publicKey, {
  //   // mode: 'C1C3C2',
  //   inputEncoding: 'utf8',
  //   // outputEncoding: 'base64'
  //   outputEncoding: 'hex'
  // })
  return encryptData
}

// 解密
export function sm2Decrypt(data) {
  const msg = data.slice(2)
  const decryptData = sm2.doDecrypt(msg, privateKey, cipherMode)
  return decryptData
}
