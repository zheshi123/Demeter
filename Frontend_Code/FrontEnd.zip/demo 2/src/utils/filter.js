// 定义了几个filter

import {isEmpty} from './validate';
import {solar2Lunar} from './index.js'

export function formatByStar(tel, frontLen = 3, endLen = 4) {
  if (isEmpty(tel)) {
    return ''
  }
  if (tel.length <= frontLen + endLen) {
    return tel
  }
  const len = tel.length - frontLen - endLen
  let star = ''
  for (let i = 0; i < len; i++) {
    star += '*'
  }
  return tel.substring(0, frontLen) + " " + star + " " + tel.substring(tel.length - endLen)
}

export function formatLunarBirth(sDate) {
  let lunarResult = solar2Lunar(sDate)
  return lunarResult
}

//祈福灯状态1-已点亮；2-已到期；0-待点亮
export function  formatMyLampStatus(status){
  let statusString = ''
  switch (status) {
    case 1:
      statusString = '已点亮'
      break
    case 0:
      statusString = '待点亮'
      break
    case 2:
      statusString = '已到期'
      break
    default:
      statusString = '已点亮'
      break
  }
  return statusString
}
export function  formatMyLampItemClick(status){
  let statusString = ''
  switch (status) {
    case 1:
      statusString = '续期'
      break
    case 0:
      statusString = '查看'
      break
    default:
      statusString = '查看'
      break
  }
  return statusString
}

export function getAge(strAge) {
  var birArr = strAge.split("-");
  var birYear = birArr[0];
  var birMonth = birArr[1];
  var birDay = birArr[2];

  d = new Date();
  var nowYear = d.getFullYear();
  var nowMonth = d.getMonth() + 1; //记得加1
  var nowDay = d.getDate();
  var returnAge;

  if (birArr == null) {
    return false
  }
  var d = new Date(birYear, birMonth - 1, birDay);
  if (d.getFullYear() == birYear && (d.getMonth() + 1) == birMonth && d.getDate() == birDay) {
    if (nowYear == birYear) {
      returnAge = 0; //
    } else {
      var ageDiff = nowYear - birYear; //
        if (nowMonth == birMonth) {
          var dayDiff = nowDay - birDay; //
          if (dayDiff < 0) {
            returnAge = ageDiff - 1;
          } else {
            returnAge = ageDiff;
          }
        } else {
          var monthDiff = nowMonth - birMonth; //
          if (monthDiff < 0) {
            returnAge = ageDiff - 1;
          } else {
            returnAge = ageDiff;
          }
        }
    }
    return returnAge
  }
}

export function parsePCAList(addressList){
  let pcaList
  let emptyItem = {
    code:'-000000',
    name:'-',
  }
  //区对象{code:'',area:''}
  let emptyAreaItem = JSON.parse(JSON.stringify(emptyItem))
  //市对象{areaList:[{code:'',area:''}],{code:'',area:''}}
  let emptyCityItem = JSON.parse(JSON.stringify({
    areaList:[emptyAreaItem],
    ...emptyItem,
  }))
  
  pcaList = addressList.map((province) => {
    let provinceItem = {}
    if(province.cityList.length <= 0){
      provinceItem.cityList = [emptyCityItem]
    }else{
      provinceItem.cityList = province.cityList.map((city) => {
        let cityItem = {}
        if(city.areaList.length <= 0){
          cityItem.areaList = [emptyAreaItem]
        }else{
          cityItem = city
        }
        cityItem.code = city.code
        cityItem.name = city.name
        return cityItem
      })
    }
    provinceItem.name = province.name
    provinceItem.code = province.code
    return provinceItem
  })
  return pcaList
}

export function showAddress(address){
  return address.replace(/[-]/g,"")
}

//查询cha在str中第num个的位置,num从1开始
/**
 * str searchString 被查找的字符串
 * cha searchElement 查找的字符
 * num index 第几个
 * */
export function findStr(str, cha, num) {
  let times = num == 0?1:num;
  var x = str.indexOf(cha);//第一次出现该字符的位置
  for (var i = 0; i < times-1; i++) {
    x = str.indexOf(cha, x + 1);
  }
  return x;
}
